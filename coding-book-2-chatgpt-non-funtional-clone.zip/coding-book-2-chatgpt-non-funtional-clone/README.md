# Coding book 2: Chatgpt non funtional clone

A Pen created on CodePen.

Original URL: [https://codepen.io/Mustafa-Upworkwala/pen/EaVWeOe](https://codepen.io/Mustafa-Upworkwala/pen/EaVWeOe).

